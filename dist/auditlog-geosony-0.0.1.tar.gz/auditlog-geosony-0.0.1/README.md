# Auditlog Python SDK

To write logs to AWS Kinesis stream

``` python

import auditlog
auditlog.writer.kinesis_writer(json_dumps_data)

```